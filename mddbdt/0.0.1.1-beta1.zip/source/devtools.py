print('MD Discord Bot Developers tools Ver.0.0.1.1-beta01')
print('2020 micchandazo Systems MDDBDT')
print('MD Discord Bot Developers toolsを起動しています...')

import discord
###ここからインポートライブラリコード###
###ここまでインポートライブラリコード###

client = discord.Client()

print('MD Discord Developers toolsにログインします。Discord Botトークンを入力してください。')
print('(ここで入力したトークンはこのアプリケーションとDiscordの接続のみに使われ、あなた以外のユーザーにはトークンを一切送信しません。)')
token = input(f'login>> ')
if token:
    print('ログインしています...')

@client.event
async def on_ready():
    print(f'ログインしました:ユーザー名{client.user.name}')
    print(f'DEVELOPERS TOOL')
    print(f'Login user name:{client.user.name}')
    print(f'Login user ID:{client.user.id}')
    print('MD Discord Bot Developers tools Ver.0.0.1.1-beta01')
    print('2020 micchandazo Systems MDDBDT')
    print('--------------------------------------------------')
    print('Developers toolsへようこそ。続行するにはEnterキーを押してください。')
    print('--------------------------------------------------')
    msc = input(f'{client.user.name}/welcome>> ')
    if msc:
        return await devtool()
    else:
        return await devtool()


@client.event
async def devtool():
    print('--------------------------------------------------')
    print(f'{client.user.name} Developers tools')
    print('1 - メッセージの管理・処理')
    ###ここからプラグインスタートアップヘルプコード###
    ###ここまでプラグインスタートアップヘルプコード###
    print('--------------------------------------------------')
    msc = input(f'{client.user.name}>> ')
    if msc == ('1'):
        print('--------------------------------------------------')
        print(f'{client.user.name} Developers tools>メッセージの管理・処理')
        print('1 - メッセージをテスト送信')
        print('r - メインメニューに戻る')
        print('--------------------------------------------------')
        msc = input(f'{client.user.name}/1>> ')
        if msc == ('1'):
            print('--------------------------------------------------')
            print(f'{client.user.name} Developers tools>メッセージの管理・処理>メッセージをテスト送信')
            print('メッセージを送信します。送信するチャンネルIDを指定してください。')
            print('--------------------------------------------------')
            mssendch = input(f'{client.user.name}/1/1>> ')
            if mssendch:
                print('--------------------------------------------------')
                print(f'{client.user.name} Developers tools>メッセージの管理・処理>メッセージをテスト送信')
                print('メッセージの内容を入力してください。')
                print('--------------------------------------------------')
                mssendms = input(f'{client.user.name}/1/1/{mssendch}>> ')
                if mssendms:
                    print('--------------------------------------------------')
                    print(f'{client.user.name} Developers tools>メッセージの管理・処理>メッセージをテスト送信')
                    print(f'{mssendch}に{mssendms}と送信します。よろしいですか？(yで実行、それ以外の文字列で中止)')
                    print('--------------------------------------------------')
                    msc = input(f'{client.user.name}/1/1/{mssendch}/...>> ')
                    if msc == ('y'):
                        mssc = int(mssendch)
                        mssch = client.get_channel(mssc)
                        print('メッセージを送信しています...')
                        await mssch.send(f'Developers toolsからメッセージを送信:{mssendms}')
                        print('メッセージを送信しました。')
                        return await devtool()
                    else:
                        return await devtool()
        if msc == ('r'):
            return await devtool()
        else:
            return await devtool()
    ###ここからプラグインスタートアップコード###
    ###ここまでプラグインスタートアップコード###
    else:
        return await devtool()

###ここからプラグインコード###
###ここまでプラグインコード###

client.run(token)
